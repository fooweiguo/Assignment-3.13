# sturdy-disco
Change #1. 

```
git add .
git commit -m "message here"
git push
```

To initialize the node application
```
npm init
npm install serverless
npm install serverless-offline --save-dev (to install serverless-offline plugin).
serverless.cmd offline start
```